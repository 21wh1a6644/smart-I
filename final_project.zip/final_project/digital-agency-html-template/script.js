document.addEventListener('DOMContentLoaded', function() {
    const chatLog = document.getElementById('chat-log');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-btn');
  
    function appendMessage(sender, message) {
      const messageElement = document.createElement('div');
      messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
      chatLog.appendChild(messageElement);
      chatLog.scrollTop = chatLog.scrollHeight;
    }
    function handleUserInput() {
        const userMessage = userInput.value.trim();
        if (userMessage !== '') {
          appendMessage('You', userMessage);
      
          // Process user input and generate a response
          const botResponse = getBotResponse(userMessage);
          setTimeout(() => appendMessage('Chatbot', botResponse), 1000);
      
          userInput.value = '';
        }
      }
      
      function getBotResponse(userMessage) {
        // Predefined responses based on specific keywords
        const greetings = ['Hi!', 'Hello!', 'Hey there!'];
        const farewells = ['Goodbye!', 'See you!', 'Take care!'];
        const thankYou = ['You\'re welcome!', 'No problem!', 'Anytime!'];
      
        // Check for specific keywords in the user's input
        if (containsKeyword(userMessage, ['hi', 'hello', 'hey'])) {
          return getRandomResponse(greetings);
        } else if (containsKeyword(userMessage, ['bye', 'goodbye'])) {
          return getRandomResponse(farewells);
        } else if (containsKeyword(userMessage, ['thanks', 'thank you'])) {
          return getRandomResponse(thankYou);
        } else {
          return 'I\'m sorry, I don\'t understand. Can you please rephrase your message?';
        }
      }
      
      function containsKeyword(message, keywords) {
        const lowerCaseMessage = message.toLowerCase();
        return keywords.some(keyword => lowerCaseMessage.includes(keyword));
      }
      
      function getRandomResponse(responses) {
        return responses[Math.floor(Math.random() * responses.length)];
      }
      
    
  
    userInput.addEventListener('keydown', function(event) {
      if (event.key === 'Enter') {
        handleUserInput();
      }
    });
  
    sendButton.addEventListener('click', function() {
      handleUserInput();
    });
  });
  